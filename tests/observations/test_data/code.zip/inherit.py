from machinable import Component


class InheritNode(Component):

    pass
