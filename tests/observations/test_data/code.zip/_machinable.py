from machinable.project import Registration


class Project(Registration):

    pass
