import machinable as ml

ml.execute("thenode")
