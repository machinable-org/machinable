from machinable import Component


class TheChildren(Component):

    attribute_ = "custom_child_attribute"
