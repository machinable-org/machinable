from .thenode import TheNode


class ChildNode(TheNode):

    pass
