from machinable import Component


class TheNode(Component):
    def config_through_config_method(self, arg):
        return arg
