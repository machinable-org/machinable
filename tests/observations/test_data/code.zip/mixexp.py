from machinable import Component


class MixinTestNode(Component):

    pass
